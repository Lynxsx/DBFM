# Copyright 2020 InterDigital Communications, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Evaluate an end-to-end compression model on an image dataset.
"""
import argparse
from skimage import data, util, io
import json
import math
import os
import sys
import time

from collections import defaultdict
from typing import List

import torch
import torch.nn as nn
import torch.nn.functional as F

from PIL import Image
from pytorch_msssim import ms_ssim
from torchvision import transforms

import compressai

from compressai.zoo import load_state_dict, models
from skimage.metrics import structural_similarity, peak_signal_noise_ratio



torch.backends.cudnn.deterministic = True
torch.set_num_threads(1)

# from torchvision.datasets.folder
IMG_EXTENSIONS = (
    ".jpg",
    ".jpeg",
    ".png",
    ".ppm",
    ".bmp",
    ".pgm",
    ".tif",
    ".tiff",
    ".webp",
)


def collect_images(rootpath: str) -> List[str]:
    return [
        os.path.join(rootpath, f)
        for f in os.listdir(rootpath)
        if os.path.splitext(f)[-1].lower() in IMG_EXTENSIONS
    ]


def psnr(a: torch.Tensor, b: torch.Tensor) -> float:
    mse = F.mse_loss(a, b).item()
    return -10 * math.log10(mse)


def read_image(filepath: str) -> torch.Tensor:
    assert os.path.isfile(filepath)
    img = Image.open(filepath).convert("RGB")
    return transforms.ToTensor()(img)


def reconstruct(reconstruction, filename, recon_path):
    reconstruction = reconstruction.squeeze()
    reconstruction.clamp_(0, 1)
    reconstruction = transforms.ToPILImage()(reconstruction.cpu())
    reconstruction.save(os.path.join(recon_path, filename))


@torch.no_grad()
def inference(model, x, filename, recon_path):
    if not os.path.exists(recon_path):
        os.makedirs(recon_path)

    x = x.unsqueeze(0)
    h, w = x.size(2), x.size(3)
    p = 64  # maximum 6 strides of 2
    new_h = (h + p - 1) // p * p
    new_w = (w + p - 1) // p * p
    padding_left = (new_w - w) // 2
    padding_right = new_w - w - padding_left
    padding_top = (new_h - h) // 2
    padding_bottom = new_h - h - padding_top
    x_padded = F.pad(
        x,
        (padding_left, padding_right, padding_top, padding_bottom),
        mode="constant",
        value=0,
    )

    start = time.time()

    out_enc = model.compress(x_padded)

    enc_time = time.time() - start
    start = time.time()
    out_dec = model.decompress(out_enc["strings"], out_enc["shape"])
    dec_time = time.time() - start

    out_dec["x_hat"] = F.pad(
        out_dec["x_hat"], (-padding_left, -padding_right, -padding_top, -padding_bottom)
    )
    reconstruct(out_dec["x_hat"], filename, recon_path)         # add

    num_pixels = x.size(0) * x.size(2) * x.size(3)
    bpp = sum(len(s[0]) for s in out_enc["strings"]) * 8.0 / num_pixels
    return {
        "psnr": psnr(x, out_dec["x_hat"]),
        "ms-ssim": ms_ssim(x, out_dec["x_hat"], data_range=1.0).item(),
        "bpp": bpp,
        "encoding_time": enc_time,
        "decoding_time": dec_time,
    }


@torch.no_grad()
def inference_entropy_estimation(model, x):
    x = x.unsqueeze(0)

    start = time.time()
    out_net = model.forward(x)
    elapsed_time = time.time() - start

    num_pixels = x.size(0) * x.size(2) * x.size(3)
    bpp = sum(
        (torch.log(likelihoods).sum() / (-math.log(2) * num_pixels))
        for likelihoods in out_net["likelihoods"].values()
    )

    return {
        "psnr": psnr(x, out_net["x_hat"]),
        "bpp": bpp.item(),
        "encoding_time": elapsed_time / 2.0,  # broad estimation
        "decoding_time": elapsed_time / 2.0,
    }


def load_checkpoint(arch: str, checkpoint_path: str) -> nn.Module:
    state_dict = load_state_dict(torch.load(checkpoint_path)['state_dict'])
    return models[arch].from_state_dict(state_dict).eval()


def eval_model(model, filepaths, entropy_estimation=False, half=False, recon_path='reconstruction'):
    device = next(model.parameters()).device
    metrics = defaultdict(float)
    for f in filepaths:
        _filename = f.split("/")[-1]

        x = read_image(f).to(device)
        if not entropy_estimation:
            if half:
                model = model.half()
                x = x.half()
            rv = inference(model, x, _filename, recon_path)
        else:
            rv = inference_entropy_estimation(model, x)
        for k, v in rv.items():
            metrics[k] += v
    for k, v in metrics.items():
        metrics[k] = v / len(filepaths)

    return metrics

def main():

    dataset = './Kodak24/'
    recon_path = './decode_image'
    architecture = 'DAVit'
    entropy_coder = compressai.available_entropy_coders()[0]
    cuda = True
    half = False
    entropy_estimation = False
    verbose = False
    paths = './output_model/Q4/checkpoint_best.pth.tar'

    # Common options.

    filepaths = collect_images(dataset)
    if len(filepaths) == 0:
        print("Error: no images found in directory.", file=sys.stderr)
        sys.exit(1)

    compressai.set_entropy_coder(entropy_coder)

    runs = paths
    opts = (architecture,)
    load_func = load_checkpoint
    log_fmt = "\rEvaluating {run:s}"

    results = defaultdict(list)
    model = load_func(*opts, runs)
    if cuda and torch.cuda.is_available():
        model = model.to("cuda")

    model.update(force=True)

    metrics = eval_model(model, filepaths, entropy_estimation, half, recon_path)
    for k, v in metrics.items():
        results[k].append(v)

    if verbose:
        sys.stderr.write("\n")
        sys.stderr.flush()

    description = (
        "entropy estimation" if entropy_estimation else entropy_coder
    )
    output = {
        "Model": architecture,
        "description": f"Inference ({description})",
        "results": results,
    }

    print(json.dumps(output, indent=2))

    total_psnr = 0.0
    total_ssim = 0.0

    for i in range(1, 25):

        origin_input = os.path.join(dataset, f"{i}.png")
        decode_input = os.path.join(recon_path, f"{i}.png")

        origin_img = io.imread(origin_input)
        rec_img = io.imread(decode_input)

        psnr_tmp = peak_signal_noise_ratio(origin_img, rec_img)
        SSIM_tmp = structural_similarity(origin_img, rec_img, multichannel=True, channel_axis=-1)

        # print(f"图像{i}的MS-SSIM值: {SSIM_tmp:.8f}")
        # print(f"图像{i}的PSNR值: {psnr_tmp:.8f}")

        total_psnr += psnr_tmp
        total_ssim += SSIM_tmp


    average_psnr = total_psnr / 24 # 图像总数
    average_ssim = total_ssim / 24
    print(f"\n平均PSNR值: {average_psnr:.8f}")
    print(f"平均SSIM值: {average_ssim:.8f}")

if __name__ == "__main__":
    main()
