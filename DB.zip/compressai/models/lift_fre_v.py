import torch
import torch.nn as nn
import torch.nn.functional as F


class LearnableLiftingWaveletForward(nn.Module):
    """
    深度学习类提升小波正变换（分解）类
    """

    def __init__(self, in_ch):
        super().__init__()
        # 可学习的预测算子（行方向）
        self.predict_rows = nn.Sequential(
            nn.Conv2d(in_ch, in_ch, kernel_size=3, padding=1, groups=in_ch),
            nn.GELU()
        )
        # 可学习的更新算子（行方向）
        self.update_rows = nn.Sequential(
            nn.Conv2d(in_ch, in_ch, kernel_size=3, padding=1, groups=in_ch),
            nn.GELU()
        )
        # 可学习的预测算子（列方向）
        self.predict_cols = nn.Sequential(
            nn.Conv2d(in_ch, in_ch, kernel_size=3, padding=1, groups=in_ch),
            nn.GELU()
        )
        # 可学习的更新算子（列方向）
        self.update_cols = nn.Sequential(
            nn.Conv2d(in_ch, in_ch, kernel_size=3, padding=1, groups=in_ch),
            nn.GELU()
        )

        self.conv_horizontal = nn.Conv2d(in_ch, in_ch, kernel_size=(1, 3), padding=(0, 1), groups=in_ch)
        self.conv_vertical = nn.Conv2d(in_ch, in_ch, kernel_size=(3, 1), padding=(1, 0), groups=in_ch)
        self.conv_diagonal = nn.Conv2d(in_ch, in_ch, kernel_size=3, padding=1, groups=in_ch)
        self.act = nn.GELU()
    def forward(self, x):
        """
        对输入张量进行深度学习类提升小波分解
        :param x: 输入张量，形状为 (B, C, H, W)
        :return: 低频分量 (LL) 和高频分量 (LH, HL, HH)
        """
        # 行方向分解
        x_even_rows = x[:, :, 0::2, :]  # 偶数行 (B, C, H/2, W)
        x_odd_rows = x[:, :, 1::2, :]  # 奇数行 (B, C, H/2, W)

        # 预测（可学习）
        d_rows = x_odd_rows - self.predict_rows(x_even_rows)

        # 更新（可学习）
        s_rows = x_even_rows + self.update_rows(d_rows)

        # 列方向分解
        s_even_cols = s_rows[:, :, :, 0::2]  # 偶数列 (B, C, H/2, W/2)
        s_odd_cols = s_rows[:, :, :, 1::2]  # 奇数列 (B, C, H/2, W/2)

        # 预测（可学习）
        d_cols = s_odd_cols - self.predict_cols(s_even_cols)

        # 更新（可学习）
        s_cols = s_even_cols + self.update_cols(d_cols)

        # 低频分量
        LL = s_cols  # (B, C, H/2, W/2)

        # 高频分量
        LH = d_cols  # (B, C, H/2, W/2)
        HL = d_rows[:, :, :, 0::2]  # (B, C, H/2, W/2)
        HH = d_rows[:, :, :, 1::2]  # (B, C, H/2, W/2)

        e_LH = self.conv_horizontal(LH)     # 增强水平方向的特征 (HL)
        e_HL = self.conv_vertical(HL)       # 增强垂直方向的特征 (HL)
        e_HH = self.conv_diagonal(HH)     # 增强对角线方向的特征 (HH)

        H_fre = self.act(e_LH + e_HL + e_HH)
        return LL, H_fre


if __name__ == "__main__":
    # 设置随机种子
    torch.manual_seed(42)

    # 创建测试张量 (B, C, H, W)
    x = torch.randn(1, 3, 64, 64)  # 1张图像，3通道，64x64分辨率
    print("输入张量形状:", x.shape)

    # 初始化深度学习类提升小波正变换和逆变换
    lifting_forward = LearnableLiftingWaveletForward(in_ch=3)

    # 提升小波分解
    LL, H_fre = lifting_forward(x)
    print("低频分量形状:", LL.shape)
    print("高频分量形状:", H_fre.shape)

