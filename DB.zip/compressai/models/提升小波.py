import torch
import torch.nn as nn


class LiftingWaveletForward(nn.Module):
    """
    提升小波正变换（分解）类
    """

    def __init__(self):
        super().__init__()

    def forward(self, x):
        """
        对输入张量进行提升小波分解
        :param x: 输入张量，形状为 (B, C, H, W)
        :return: 低频分量 (LL) 和高频分量 (LH, HL, HH)
        """
        # 行方向分解
        x_even_rows = x[:, :, 0::2, :]  # 偶数行 (B, C, H/2, W)
        x_odd_rows = x[:, :, 1::2, :]  # 奇数行 (B, C, H/2, W)

        # 预测（简单线性插值）
        d_rows = x_odd_rows - 0.5 * (x_even_rows + torch.roll(x_even_rows, -1, dims=2))

        # 更新（简单加权平均）
        s_rows = x_even_rows + 0.25 * (d_rows + torch.roll(d_rows, 1, dims=2))

        # 列方向分解
        s_even_cols = s_rows[:, :, :, 0::2]  # 偶数列 (B, C, H/2, W/2)
        s_odd_cols = s_rows[:, :, :, 1::2]  # 奇数列 (B, C, H/2, W/2)

        # 预测（简单线性插值）
        d_cols = s_odd_cols - 0.5 * (s_even_cols + torch.roll(s_even_cols, -1, dims=3))

        # 更新（简单加权平均）
        s_cols = s_even_cols + 0.25 * (d_cols + torch.roll(d_cols, 1, dims=3))

        # 低频分量
        LL = s_cols  # (B, C, H/2, W/2)

        # 高频分量
        LH = d_cols  # (B, C, H/2, W/2)
        HL = d_rows[:, :, :, 0::2]  # (B, C, H/2, W/2)
        HH = d_rows[:, :, :, 1::2]  # (B, C, H/2, W/2)

        return LL, LH, HL, HH



# 测试代码
if __name__ == "__main__":
    # 设置随机种子
    torch.manual_seed(42)

    # 创建测试张量 (B, C, H, W)
    x = torch.randn(1, 3, 64, 64)  # 1张图像，3通道，64x64分辨率
    print("输入张量形状:", x.shape)

    # 初始化提升小波正变换和逆变换
    lifting_forward = LiftingWaveletForward()

    # 提升小波分解
    LL, LH, HL, HH = lifting_forward(x)
    print("低频分量 (LL) 形状:", LL.shape)
    print("高频分量 (LH) 形状:", LH.shape)
    print("高频分量 (HL) 形状:", HL.shape)
    print("高频分量 (HH) 形状:", HH.shape)